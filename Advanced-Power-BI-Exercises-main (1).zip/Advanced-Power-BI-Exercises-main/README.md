# Advanced-Power-BI-Exercises
Thank you for attending the Innovia Consulting Advanced Power BI workshop.

This repository includes all the files you will need to get started with our exercises, as well as some sample code snippets to help you get started and follow along.

- Any files we will be using in the practical exercises will be listed in the folder "files."
- Any code snippets we will be covering in the exercises or the presentation are available in the "code-snippets" folder.
- We also have some solution files to help you verify that you followed the correct procedure. Feel free to use them when indicated in the instructions.

Enjoy the workshop!
